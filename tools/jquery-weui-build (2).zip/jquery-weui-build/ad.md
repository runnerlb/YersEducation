# 加入推广（广告）

## 为什么选择？

- 受众精准，直接面向前端开发者群体
- 用户活跃，日UV3000+，日PV8000+，月活跃用户 1W+
- 价格透明，童叟无欺

## 价格

**首页广告**

- 200元/月，可以放一张图片和一段说明文字，或者直接放一张大图，具体形式请直接参考首页。

- 仅在首页展示，其他页面不会展示，总共三个展示位

**Banner侧广告**

- 500/月, 在主要的页面（首页，组件，拓展组件等）的Banner区都会展示, 只有一个展示位，先到先得。

## 立刻加入

微信或者支付宝转账，并注明QQ号，之后我会加你QQ并沟通详细内容。

<img src="https://raw.githubusercontent.com/lihongxun945/jquery-weui/master/vcode/alipay.jpg" width="250" />
<img src="https://raw.githubusercontent.com/lihongxun945/jquery-weui/master/vcode/wechat.jpg" width="250" />

## 为何加入广告？

放入广告只是想探索一下开源项目的盈利模式，至少能把服务器和域名的钱赚回来，希望大家能理解。

希望作为jQuery WeUI的用户不会被广告困扰。目前广告只在页面顶部会出现，以后也不会出现类似弹窗或者随屏幕滚动的比较干扰体验的广告。
